"""Database integration boundary."""
